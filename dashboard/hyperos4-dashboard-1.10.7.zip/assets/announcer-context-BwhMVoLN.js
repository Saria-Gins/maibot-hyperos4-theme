import{a as t}from"./index-BEbHXjak.js";const e=t.createContext(null);function r(){const n=t.useContext(e);return n?n.announce:()=>{}}export{e as A,r as u};
