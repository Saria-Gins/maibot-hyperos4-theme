import{A as s}from"./api-base-DrtcSpTC.js";function o(r,e){if(!r.success)throw new s(r.message||e,{detail:r});return r}export{o as r};
