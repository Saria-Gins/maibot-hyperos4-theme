import{a as t}from"./index-BEbHXjak.js";const a=t.createContext(void 0);export{a as A};
