const a="1.10.7",s="MaiBot Dashboard",o=`${s} ${a}`;export{o as A,a,s as b};
