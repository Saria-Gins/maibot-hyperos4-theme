import{a as t}from"./index-BEbHXjak.js";const r=t.createContext(null);export{r as T};
