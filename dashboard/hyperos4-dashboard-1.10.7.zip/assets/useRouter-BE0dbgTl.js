import{a as t}from"./index-BEbHXjak.js";var e=t.createContext(null);function a(r){return t.useContext(e)}export{e as r,a as u};
