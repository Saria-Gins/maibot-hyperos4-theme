import{r as n,aW as o}from"./index-Cgeh5B36.js";const r=()=>{const t=n.useContext(o);if(t===void 0)throw new Error("useAnimation must be used within an AnimationProvider");return t};export{r as u};
