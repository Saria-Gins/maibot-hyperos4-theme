import{ap as e}from"./index-Cgeh5B36.js";const a=[["path",{d:"M12 19h8",key:"baeox8"}],["path",{d:"m4 17 6-6-6-6",key:"1yngyt"}]],t=e("terminal",a);export{t as T};
