import{j as s,m as a}from"./index-Cgeh5B36.js";function n({className:e,...r}){return s.jsx("div",{className:a("animate-pulse rounded-md bg-primary/10",e),...r})}export{n as S};
