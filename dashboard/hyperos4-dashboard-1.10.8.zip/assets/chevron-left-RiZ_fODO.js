import{ap as e}from"./index-Cgeh5B36.js";const o=[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]],c=e("chevron-left",o);export{c as C};
