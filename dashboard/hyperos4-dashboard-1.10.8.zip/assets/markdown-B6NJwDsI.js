import{j as n}from"./index-Cgeh5B36.js";import{MarkdownRenderer as t}from"./markdown-renderer-bS994FzL.js";function s({children:r,className:o}){return n.jsx(t,{content:r,className:o})}export{s as M};
