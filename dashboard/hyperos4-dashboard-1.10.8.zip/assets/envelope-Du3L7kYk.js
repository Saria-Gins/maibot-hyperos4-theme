import{bf as s}from"./index-Cgeh5B36.js";function o(r,e){if(!r.success)throw new s(r.message||e,{detail:r});return r}export{o as r};
